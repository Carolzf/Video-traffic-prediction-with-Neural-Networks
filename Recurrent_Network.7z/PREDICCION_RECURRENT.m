clc;
clear;
close all;
load('trafico1');

Ca=data(:,2);
mx=max(Ca);mn=min(Ca);mmd=mx-mn;% Maximos y minimos
for i=1:size(Ca,1)
       xn(i,:)=((Ca(i,:)-mn+(mmd==0))./(mmd+(mmd==0)*2))*2; 
end
%SERIE A TRABAJAR (MATRIX)(FRAME/FSIZE)
frame=data(1:12000,1)';
sizee=xn(1:12000,1)';
traf=[sizee frame];
fsize=sizee;
%PLOT TRAMA ORIGINAL
figure;
plot(frame,fsize);
hold on
%INDEXING 1 FRAME DE ENTRADA PARA PREDECIR LOS SIGUIENTES 5
n = 12000;
a = 1:n;
p = 6;
X = zeros(n/p,p);
for i=1:p
    X(:,i) = a(mod(a,p) == i-1);
end
X=[X X(:,1)];

%DATOS DE ENTRADA Y SALIDA (1 entradas, 5 salidas)
x=fsize(X(:,2));
t=fsize(X(:,3:7))';
%ARQUITECTURA
net=layrecnet(1:2,[10 10]);
view(net)
%Función de entrenamiento
net.trainFcn = 'trainlm'; %trainlm,trainrp y trainbr
%net.layers{[1 2 3]}.transferFcn = 'logsig';
%net.layers{[1 2]}.transferFcn = 'logsig';
%net.layers{1}.transferFcn = 'logsig';

%Division de datos
net.divideParam.trainRatio = 0.7; %Entrenamiento
net.divideParam.valRatio   = 0.2; %Validación
net.divideParam.testRatio  = 0.1; %Test
%Parámetros de entrenamiento (criterios de parada)
net.trainParam.max_fail = 10;     %Fallos máximos de validación                  
net.trainParam.epochs =   1000;   %Número máximo de épocas a entrenar                  
net.trainParam.goal =     0;      %Objetivo de rendimiento              	
net.trainParam.min_grad = 1e-10;  %Gradiente de rendimiento mínimo                 
%ENTRENAMIENTO
[net,tr,y,ee] = train(net,x,t);
%SIMULACIÓN
simu = sim(net,x);
%a=net(x);
%ARREGLO DATOS PARA PLOT
trans=[x' simu'];
for i=0:1999
serie(1,(6*i)+1:(6*i)+6)=trans(i+1,:);
end
plot(frame,serie','--');
legend('Real','Predicción');
title('Predicción tráfico de vídeo VBR');
xlabel('Frames');
ylabel('Frame size (Bytes)');

%MAE 
errc1=abs(fsize-serie);
serrc1=sum(errc1);
mae1=serrc1./length(fsize);
%MSE 
errc11=(fsize-serie).^2;
serrc11=sum(errc11);
mse1=serrc11./length(fsize);

%SERIE PARA PROBAR (LORD OF THE RINGS)
load('lord_of_rings.mat');
Ca2=data2(:,2);
mx2=max(Ca2);mn2=min(Ca2);mmd2=mx2-mn2;% Maximos y minimos
for j=1:size(Ca2,1)
       xn2(j,:)=((Ca2(j,:)-mn2+(mmd2==0))./(mmd2+(mmd2==0)*2))*2; 
end

%SERIE A TRABAJAR (FRAME/FSIZE)
frame2=data2(1:12000,1)';
size2=xn2(1:12000,1)';
traf2=[size2 frame2];
fsize2=size2;
figure;
plot(frame2,fsize2);
hold on
%INDEXING 1 FRAME DE ENTRADA PARA PREDECIR LOS SIGUIENTES 5
n2 = 12000;
a2 = 1:n2;
p2 = 6;
X2 = zeros(n2/p2,p2);
for i=1:p2
    X2(:,i) = a2(mod(a2,p2) == i-1);
end
X2=[X2 X2(:,1)];

%DATOS DE ENTRADA Y SALIDA (1 entradas, 5 salidas)
xx=fsize2(X2(:,2));
tt=fsize2(X2(:,3:7))';
%SIMULACIÓN
aa = sim(net,xx);

%ARREGLO DATOS PARA PLOT
trans2=[xx' aa'];
for i=0:1999
serie2(1,(6*i)+1:(6*i)+6)=trans2(i+1,:);
end
plot(frame2,serie2','--');
legend('Real','Predicción');
title('Predicción tráfico de vídeo VBR');
xlabel('Frames');
ylabel('Frame size (Bytes)');

%MAE 
errc2=abs(fsize2-serie2);
serrc2=sum(errc2);
mae2=serrc2./length(fsize2);
%MSE 
errc22=(fsize2-serie2).^2;
serrc22=sum(errc22);
mse2=serrc22./length(fsize2);